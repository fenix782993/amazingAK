﻿#NoEnv
#SingleInstance Force
#Persistent
SendMode Input
SetWorkingDir %A_ScriptDir%

#include UDF.ahk

ActiveID = 0
UserID =
State3 = 0

!Y::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 300
sendChat("Здравия желаю. Лейтенант полиции - Динеро.")
Return

^Y::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Удостоверение находится в правом кармане.")
Sleep, 3000
sendChat("/me движением правой руки достал из правого кармана удостоверение")
Sleep, 3000
sendChat("/do Удостоверение в правой руке.")
Sleep, 3000
sendChat("/me раскрыл удостоверение, затем показал человеку напротив на уровне глаз, не передавая в руки")
Sleep, 3000
sendChat("/me после ознакомления убрал удостоверение обратно в нагрудный карман")
Return

!1::
SendMessage, 0x50,, 0x4190419,, A
Sleep 500
SendInput, {F6}{space}
Sleep 50
Input, UserID, I L6 V, {Enter}

If ActiveID == 0
{
    CustomColor3 = EEAA99
    Gui +LastFound +AlwaysOnTop -Caption +ToolWindow 
    Gui, Color, black
    Gui, Font, s7
    Gui, Font, cWhite
    Gui, Font, w%Скорость1%0
    GUI, ADD, TEXT,, ID = %UserID%
    WinSet, TransColor, %CustomColor3% 180
    Gui, Show, x5 y50 NoActivate, window.	
}
Else
{
    Gui Destroy
    CustomColor3 = EEAA99
    Gui +LastFound +AlwaysOnTop -Caption +ToolWindow 
    Gui, Color, black
    Gui, Font, s7
    Gui, Font, cWhite
    Gui, Font, w%Скорость1%0
    GUI, ADD, TEXT,, ID = %UserID%
    WinSet, TransColor, %CustomColor3% 180
    Gui, Show, x5 y50 NoActivate, window.
}
Return

!2::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 500

If UserID < 1000
{
    sendChat("/chase " UserID)
}
Else
{
    sendChat("/chaseid " UserID)
}
Return

!3::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 500
SendInput, {F6}
Sleep, 50
SendInput, /incar %UserID%{Enter}
Return

!4::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 500

If UserID < 1000
{
    sendChat("/deject " UserID)
}
Else
{
    sendChat("/dejectid " UserID)
}
Return

!5::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 500
SendInput, {F6}
Sleep, 50
SendInput, /cuff %UserID%{Enter}
Sleep, 3000
SendInput, {F6}
Sleep, 50
SendInput, /frac %UserID%{Enter}
Sleep, 3000
SendInput, {1}
Sleep, 50
SendInput, {1}
Sleep, 3000
SendInput, {4}
Sleep, 50
SendInput, {4}
Return

!7::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 500
sendChat("/m [УГИБДД] Водитель, останавливаемся и прижимаемся к обочине!")
Sleep, 3000
sendChat("/m [УГИБДД] В случае неподчинения, я открываю огонь по колёсам!")
Return

!8::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 500
sendChat("/m [УГИБДД] Водитель, уходим в другую полосу!")
Sleep, 3000
sendChat("/m [УГИБДД] Пропускаем спец. транспорт!")
Return

:?:!деп::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 300
sendChat("/d [УГИБДД] Докладывает: Динеро.")
Return

:?:!миранда::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 1000
sendChat("Гражданин, разъясняю Вам Ваши права!")
Sleep, 3000
sendChat("Вы имеете право на отказ от дачи показаний против себя и своих близких.")
Sleep, 3000
sendChat("Вы имеете право на юридическую помощь с момента доставления Вас в ИВС.")
Sleep, 3000
sendChat("Вы имеете право на обжалование моих действий в судебном порядке.")
Sleep, 3000
sendChat("Права Вам разъяснены.")
Return

:?:!ук::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Кожаная папка находится в руке.")
Sleep, 3000
sendChat("/me открыл папку, затем достал чистый протокол с ручкой")
Sleep, 3000
sendChat("/me взяв протокол и ручку в руки начал заполнять протокол")
Sleep, 3000
sendChat("/me указал в протоколе ФИО задержанного, дату рождения")
Sleep, 3000
sendChat("/me также указал время задержания, дату задержания, причину задержания")
Sleep, 3000
sendChat("/todo Задержанный, ознакомьтесь с протоколом и распишитесь")
Sleep, 3000
sendChat("/me передал протокол человеку, в отношении которого он составлен")
Return

:?:!коап::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Кожаная папка находится в руке.")
Sleep, 3000
sendChat("/me открыл папку, затем достал чистый протокол об АПН с ручкой")
Sleep, 3000
sendChat("/me взяв протокол и ручку в руки начал заполнять протокол")
Sleep, 3000
sendChat("/do Происходит процесс заполнения протокола.")
Sleep, 3000
sendChat("/me передал протокол человеку, в отношении которого он составлен")
Return

:?:!сос::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Выехал на вызов SOS.")
Return

:?:!сос1::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Прибыл на вызов SOS.")
Return

:?:!выз::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Реагирую на вызов от гражданского.")
Return

:?:!выз1::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Прибыл на вызов от гражданского.")
Return

:?:!ограб::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Выехал на вызов об ограблении.")
Return

:?:!ограб1::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Прибыл на вызов об ограблении.")
Return

:?:!обморок::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me снимает набор ПП с плеча и достает аптечку")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me проверяет пульс человека")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me проверяет дыхание человека")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Человек в обмороке.")
Sleep, 3000
sendChat("/me перекладывает человека в горизонтальное положение тела")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me расслабляет стесняющие дыхание элементы одежды")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me пробует привести человека в сознание")
Return

:?:!обморок112::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон и звонит 112, сообщая место, пол и примерный возраст человека")
Sleep, 3000
sendChat("/me проверяет дыхание, пульс, переворачивает человека набок")
Sleep, 3000
sendChat("/me дабы в случае рвоты тот не захлебнулся")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me пробует привести человека в сознание")
Return

:?:!артерия::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me берет телефон и вызывает СМП, затем достает аптечку, открывает и кладет на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me пережимает артерию кулаком в месте ранения, параллельно доставая бинты со жгутом")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me перевязывает место наложения жгута бинтом и накладывает жгут на это место")
Sleep, 3000
sendChat("/me выше ранения, делая первые два тура тугими")
Sleep, 3000
sendChat("/me достает бумажку и ручку, затем записывает время наложения жгута")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Кровотечение прекращено.")
Return

:?:!вена::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка открыта на полу.")
Sleep, 3000
sendChat("/me протягивает руку в аптечку, после чего берет оттуда марлю")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me накладывает марлю на рану")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me достает из аптечки бинт и вату, после чего кладет вату на марлю и туго бинтует")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Давящая повязка наложена. Кровотечение прекращено.")
Return

:?:!капилляр::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка открыта на полу.")
Sleep, 3000
sendChat("/me достает из аптечки антисептическую повязку")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Антисептическая повязка в руках.")
Sleep, 3000
sendChat("/me обматывает антисептическую повязку на руку")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Кровотечение прекращено.")
Return

:?:!открытый::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me кладет человека на пол")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Человек в горизонтальном положении.")
Sleep, 3000
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me достает медицинскую шину, накладывая ее на место перелома")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me берет бинты и фиксирует ими шину")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Шина зафиксирована.")
Return

:?:!закрытый::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me кладет человека на пол в горизонтальное положение")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Человек в горизонтальном положении.")
Sleep, 3000
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me достает из аптечки медицинскую шину, накладывая ее на место перелома")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me берет бинты и фиксирует ими шину")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Шина зафиксирована.")
Return

:?:!обморожение::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me берет человека под руку и ведет в теплое место")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me начинает осторожно растирать пораженные места")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me достает из разгрузки аптечку и согревающую повязку")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me накладывает повязку на пораженные участки тела")
Sleep, 3000
sendChat("/do Процесс...")
Return

:?:!пуля::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон, вызывает скорую медицинскую помощь")
Sleep, 3000
sendChat("/me запрокидывает голову человека назад, чуть ее поворачивая")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открывает ее и ставит на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me достает шприц с обезболивающим из аптечки")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me вкалывает обезболивающее человеку")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me достает зеленку из аптечки и обрабатывает ею края раны")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me достает давящую повязку из аптечки и накладывает ее на пулевое отверстие")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Первая помощь оказана.")
Return

:?:!визитка::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do На визитке написано: Динеро.")
Sleep, 3000
sendChat("/b Это все социальные сети.")
Return

!F1::
sendChat("/me открыл дверь автомобиля, затем посадил задержанного в авто")
Sleep, 3000
sendChat("/do Задержанный в автомобиле.")
Sleep, 3000
sendChat("/me пристегнул ремень безопасности, затем закрыл дверь автомобиля")
Sleep, 3000
sendChat("/me закрыл дверь автомобиля")
Return

!F2::
sendChat("/me открыл дверь автомобиля, затем отстегнул ремень безопасности")
Sleep, 3000
sendChat("/do Задержанный в автомобиле.")
Sleep, 3000
sendChat("/me достал из автомобиля задержанного, взял за руку")
Sleep, 3000
sendChat("/me закрыл дверь автомобиля")
Return

!F3::
sendChat("/do Тактические перчатки на руках.")
Sleep, 3000
sendChat("/me начал досматривать человека напротив")
Sleep, 3000
sendChat("/me прохлопал верхний, затем нижний слои одежды человека напротив")
Return

!F4::
sendChat("/do Подсумок на поясном держателе.")
Sleep, 3000
sendChat("/me открыл подсумок, затем достал оттуда зип-пакет")
Sleep, 3000
sendChat("/do Зип-пакет в руках.")
Sleep, 3000
sendChat("/me начал изымать содержимое у человека")
Sleep, 3000
sendChat("/do Содержимое в зип-пакете.")
Sleep, 3000
sendChat("/me закрыл зип-пакет, затем повесил на поясной держатель")
Return

!F5::
sendChat("/call 97710514")
Sleep, 3000
sendChat("/h")
Return

!X::
State3 := !State3

If State3
{
    Gui, Destroy
    Gui, +LastFound +AlwaysOnTop -Caption +ToolWindow +E0x20 +Owner
    
    Gui, Color, 0D1117
    Gui, Margin, 0, 0

    Gui, Font, s12 c00FFFF Bold, Segoe UI
    Gui, Add, Text, x20 y15 w680 h28 Center, FENIX DPS HELPER

    Gui, Font, s8 c007BFF, Segoe UI
    Gui, Add, Text, x20 y45 w680 h2 0x10

    Gui, Font, s9 cA0AAB5 Norm, Segoe UI
    Gui, Add, Text, x25 y60 w90 h22, Владелец:

    Gui, Font, s9 c00FF88 Bold, Segoe UI
    Gui, Add, Text, x115 y60 w250 h22, Fenix_Dinero

    Gui, Font, s9 cA0AAB5 Norm, Segoe UI
    Gui, Add, Text, x385 y60 w70 h22, Telegram:

    Gui, Font, s9 c00FFFF Bold, Segoe UI
    Gui, Add, Text, x455 y60 w230 h22, @webFenix

    If UserID
    {
        Gui, Font, s9 cA0AAB5 Norm, Segoe UI
        Gui, Add, Text, x25 y88 w90 h22, Текущий ID:

        Gui, Font, s9 cFF9F43 Bold, Segoe UI
        Gui, Add, Text, x115 y88 w150 h22, %UserID%
    }

    Gui, Font, s8 c007BFF, Segoe UI
    Gui, Add, Text, x20 y118 w680 h2 0x10

    Gui, Font, s10 c00D2FF Bold, Segoe UI
    Gui, Add, Text, x25 y135 w320 h25, ОСНОВНЫЕ КОМАНДЫ

    Gui, Font, s8 cFFFFFF Norm, Segoe UI
    Gui, Add, Text, x25 y165 w320 h22, Alt + Y - Представиться
    Gui, Add, Text, x25 y190 w320 h22, Ctrl + Y - Удостоверение
    Gui, Add, Text, x25 y215 w320 h22, Alt + 1 - Ввести ID
    Gui, Add, Text, x25 y240 w320 h22, Alt + 2 - Преследование
    Gui, Add, Text, x25 y265 w320 h22, Alt + 3 - Посадить в авто
    Gui, Add, Text, x25 y290 w320 h22, Alt + 4 - Высадить из авто
    Gui, Add, Text, x25 y315 w320 h22, Alt + 5 - Наручники + залом
    Gui, Add, Text, x25 y340 w320 h22, Alt + F1 - Посадка в авто
    Gui, Add, Text, x25 y365 w320 h22, Alt + F2 - Высадка из авто
    Gui, Add, Text, x25 y390 w320 h22, Alt + F3 - Досмотр
    Gui, Add, Text, x25 y415 w320 h22, Alt + F4 - Изъятие
    Gui, Add, Text, x25 y440 w320 h22, Alt + F5 - Сбив маски
    Gui, Add, Text, x25 y465 w320 h22, Alt + 7 - Остановка
    Gui, Add, Text, x25 y490 w320 h22, Alt + 8 - Спецтранспорт

    Gui, Font, s10 cFFC107 Bold, Segoe UI
    Gui, Add, Text, x365 y135 w320 h25, БЫСТРЫЕ ОТЫГРОВКИ

    Gui, Font, s8 cE0E6ED Norm, Segoe UI
    Gui, Add, Text, x365 y165 w320 h22, !миранда - Права задержанного
    Gui, Add, Text, x365 y190 w320 h22, !ук - Оформление в отделе
    Gui, Add, Text, x365 y215 w320 h22, !коап - Протокол КоАП
    Gui, Add, Text, x365 y240 w320 h22, !сос - Выезд на SOS
    Gui, Add, Text, x365 y265 w320 h22, !сос1 - Прибытие на SOS
    Gui, Add, Text, x365 y290 w320 h22, !выз - Выезд на вызов
    Gui, Add, Text, x365 y315 w320 h22, !выз1 - Прибытие на вызов
    Gui, Add, Text, x365 y340 w320 h22, !ограб - Выезд на ограбление
    Gui, Add, Text, x365 y365 w320 h22, !ограб1 - Прибытие

    Gui, Font, s10 cFF4757 Bold, Segoe UI
    Gui, Add, Text, x365 y405 w320 h25, МЕДИЦИНА

    Gui, Font, s8 cE0E6ED Norm, Segoe UI
    Gui, Add, Text, x365 y435 w320 h22, !обморок - Обморок
    Gui, Add, Text, x365 y460 w320 h22, !обморок112 - Вызов СМП
    Gui, Add, Text, x365 y485 w320 h22, !артерия - Артериальное
    Gui, Add, Text, x365 y510 w320 h22, !венозное - Венозное
    Gui, Add, Text, x365 y535 w320 h22, !капилляр - Капиллярное

    Gui, Font, s8 c707B8C Norm, Segoe UI
    Gui, Add, Text, x25 y565 w320 h22, Fenix Helper - AMAZING ONLINE

    Gui, Font, s8 c00D2FF Bold, Segoe UI
    Gui, Add, Text, x365 y565 w320 h22 Right, Telegram: @webFenix

    Gui, Font, s8 c007BFF, Segoe UI
    Gui, Add, Text, x20 y595 w680 h2 0x10

    Gui, Font, s8 c8A99AD Norm, Segoe UI
    Gui, Add, Text, x20 y610 w680 h20 Center, Alt + X - закрыть / открыть меню

    Gui, Show, x10 y10 w720 h645 NoActivate, Fenix DPS Helper

    WinSet, Transparent, 210, Fenix DPS Helper
    
    If WinExist("AMAZING ONLINE")
        WinActivate, AMAZING ONLINE
}
Else
{
    Gui, Destroy
}
Return
