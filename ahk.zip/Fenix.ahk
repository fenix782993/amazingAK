﻿#NoEnv
#SingleInstance Force
#Persistent
SetWorkingDir %A_ScriptDir%
SendMode Input

#include UDF.ahk

global UserID := ""
global State3 := 0

SetTimer, RGB_Logic, 150
SetTimer, RGB_Logic, Off

!1::
if (isInChat())
{
    Return
}
SendMessage, 0x50,, 0x4190419,, A
addChatMessageEx("0x00FF88", "[Fenix Helper] Vvedite ID igroka v chat и нажмите Enter...")
SendInput, {F6}
Input, RawID, L4 T5, {Enter}{Escape}
if (ErrorLevel = "Timeout" || ErrorLevel = "EndKey:Escape")
{
    addChatMessageEx("0xFF0000", "[Fenix Helper] Vvod otmenen ili vyshlo vremya.")
    Return
}
SendInput, {CtrlDown}a{CtrlUp}{BackSpace}{Enter}
StringReplace, CleanedID, RawID, %A_Space%, , All
if CleanedID is integer
{
    UserID := CleanedID
    addChatMessageEx("0x00FFFF", "[Fenix Helper] ID " . UserID . " uspeshno sohranen!")
}
else
{
    addChatMessageEx("0xFF0000", "[Fenix Helper] Oshibka: Nujno vvodit tolko cifry ID!")
}
Return

:?:/fnh::
Input, ManualID, V L4, {Enter}{Space}
StringReplace, ManualID, ManualID, %A_Space%, , All
if ManualID is integer
{
    UserID := ManualID
    addChatMessageEx("0x00FFFF", "[Fenix Helper] ID " . UserID . " uspeshno sohranen!")
}
Return

!2::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 200
If (UserID != "") {
    If (UserID < 1000)
        sendChat("/chase " . UserID)
    Else
        sendChat("/chaseid " . UserID)
} else {
    addChatMessageEx("0xFF0000", "[Fenix Helper] Oshibka: ID ne ustanovlen! Jmite Alt + 1")
}
Return

!3::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 200
If (UserID != "")
    sendChat("/incar " . UserID)
else
    addChatMessageEx("0xFF0000", "[Fenix Helper] Oshibka: ID ne ustanovlen!")
Return

!4::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 200
If (UserID != "") {
    If (UserID < 1000)
        sendChat("/deject " . UserID)
    Else
        sendChat("/dejectid " . UserID)
} else {
    addChatMessageEx("0xFF0000", "[Fenix Helper] Oshibka: ID ne ustanovlen!")
}
Return

!5::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 200
If (UserID != "") {
    sendChat("/cuff " . UserID)
    Sleep, 3000
    sendChat("/frac " . UserID)
} else {
    addChatMessageEx("0xFF0000", "[Fenix Helper] Oshibka: ID ne ustanovlen!")
}
Return

!6::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 200
sendChat("/m [УГИБДД] Водитель, снижаем скорость и прижимаемся к обочине!")
Return

!7::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 200
sendChat("/m [УГИБДД] Водитель, останавливаемся и прижимаемся к обочине!")
Sleep, 3000
sendChat("/m [УГИБДД] В случае неподчинения, я открываю огонь по колёсам!")
Return

!8::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 200
sendChat("/m [УГИБДД] Водитель, уходим в другую полосу!")
Sleep, 3000
sendChat("/m [УГИБДД] Пропускаем спец. транспорт!")
Return

!9::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает генератор радиопомех, активирует его и ставит на пол")
Sleep, 3000
sendChat("/me снимает набор сапера с разгрузки, ставит его на пол и открывает")
Sleep, 3000
sendChat("/me достает инжекторную отвертку и кусачки из набора")
Sleep, 3000
sendChat("/me начал осматривать устройство, после чего откручивает крышку устройства")
Sleep, 3000
sendChat("/me начинает прозванивать провода, находит нужный провод и перерезает его")
Sleep, 3000
sendChat("/do СВУ обесточено.")
Sleep, 3000
sendChat("/me снимает с разгрузки кейс, открыл его и поставил на пол")
Sleep, 3000
sendChat("/me выкручивает из СВУ тротиловую шашку из тротиловой шашки взрыватель а из взрывателя капсюль")
Sleep, 3000
sendChat("/me легким движением руки раскладывает компоненты СВУ в кейс, и зацепляет на лямки бронежилет")
Sleep, 3000
sendChat("/do СВУ обезврежено.")
Return

!0::
if (isInChat())
    Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me снимает набор сапёра с разгрузки, открывает его, затем достает оттуда инжекторную отвертку")
Sleep, 3000
sendChat("/me начинает осматривать взрывное устройство, после чего откручивает крышку")
Sleep, 3000
sendChat("/me достает кейс с крепления бронежилета, открывает его и ставит на пол")
Sleep, 3000
sendChat("/me выкручивает из СВУ тротиловую шашку, шашку взрывателя, капсюль")
Sleep, 3000
sendChat("/me раскладывает компоненты СВУ в кейс, закрывает кейс, вешает на крепления бронежилета")
Sleep, 3000
sendChat("/do СВУ обезврежено.")
Return

!F1::
if (isInChat()) Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me открыл дверь автомобиля, затем посадил задержанного в авто")
Sleep, 3000
sendChat("/do Задержанный в автомобиле.")
Sleep, 3000
sendChat("/me пристегнул ремень безопасности, затем закрыл дверь автомобиля")
Return

!F2::
if (isInChat()) Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me открыл дверь автомобиля, затем отстегнул ремень безопасности")
Sleep, 3000
sendChat("/do Задержанный в автомобиле.")
Sleep, 3000
sendChat("/me достатал из автомобиля задержанного, взял за руку")
Sleep, 3000
sendChat("/me закрыл дверь автомобиля")
Return

!F3::
if (isInChat()) Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Тактические перчатки на руках.")
Sleep, 3000
sendChat("/me начал досматривать человека напротив")
Sleep, 3000
sendChat("/me прохлопал верхний, затем нижний слои одежды человека напротив")
Return

!F4::
if (isInChat()) Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Подсумок на поясном держателе.")
Sleep, 3000
sendChat("/me открыл подсумок, затем достал оттуда зип-пакет")
Sleep, 3000
sendChat("/do Зип-пакет в руках.")
Sleep, 3000
sendChat("/me начал изымать содержимое у человека")
Sleep, 3000
sendChat("/do Содержимое в зип-пакете.")
Sleep, 3000
sendChat("/me закрыл зип-пакет, затем повесил на поясной держатель")
Return

!F5::
if (isInChat()) Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/call 97710514")
Sleep, 3000
sendChat("/h")
Return

:?:!визитка::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me плавно засунул руку в карман брюк, достал оттуда визитку и передал человеку напротив")
Sleep, 3000
sendChat("/do На визитке написано: Динеро | VK: webFenix | Telegram: @webFenix.")
Sleep, 3000
sendChat("/b Связь со мной: VK: webFenix | TG: @webFenix")
Return

!Y::
if (isInChat()) Return
SendMessage, 0x50,, 0x4190419,, A
Sleep, 300
sendChat("Здравия желаю. Лейтенант полиции - Динеро.")
Return

^Y::
if (isInChat()) Return
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Удостоверение находится в правом кармане.")
Sleep, 3000
sendChat("/me движением правой руки достал из правого кармана удостоверение")
Sleep, 3000
sendChat("/do Удостоверение в правой руке.")
Sleep, 3000
sendChat("/me раскрыл удостоверение, затем показал человеку напротив на уровне глаз, не передавая в руки")
Sleep, 3000
sendChat("/me после ознакомления убрал удостоверение обратно в нагрудный карман")
Return

:?:!деп::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 300
sendChat("/d [УГИБДД] Докладывает: Динеро.")
Return

:?:!миранда::
SendMessage, 0x50,, 0x4190419,, A
Sleep, 1000
sendChat("Гражданин, разъясняю Вам Ваши права!")
Sleep, 3000
sendChat("Вы имеете право на отказ от дачи показаний против себя и своих близких.")
Sleep, 3000
sendChat("Вы имеете право на юридическую помощь с момента доставления Вас в ИВС.")
Sleep, 3000
sendChat("Вы имеете право на обжалование моих действий в судебном порядке.")
Sleep, 3000
sendChat("Права Вам разъяснены.")
Return

:?:!ук::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Кожаная папка находится в руке.")
Sleep, 3000
sendChat("/me открыл папку, затем достал чистый протокол с ручкой")
Sleep, 3000
sendChat("/me взяв протокол и ручку в руки начал заполнять протокол")
Sleep, 3000
sendChat("/me указал в протоколе ФИО задержанного, дату рождения")
Sleep, 3000
sendChat("/me также указал время задержания, дату задержания, причину задержания")
Sleep, 3000
sendChat("/todo Задержанный, ознакомьтесь с протоколом и распишитесь")
Sleep, 3000
sendChat("/me передал протокол человеку, в отношении которого он составлен")
Return

:?:!коап::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/do Кожаная папка находится в руке.")
Sleep, 3000
sendChat("/me открыл папку, затем достал чистый протокол об АПН с ручкой")
Sleep, 3000
sendChat("/me взяв протокол и ручку в руки начал заполнять протокол")
Sleep, 3000
sendChat("/do Происходит процесс заполнения протокола.")
Sleep, 3000
sendChat("/me передал протокол человеку, в отношении которого он составлен")
Return

:?:!сос::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Выехал на вызов SOS.")
Return

:?:!сос1::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Прибыл на вызов SOS.")
Return

:?:!выз::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Реагирую на вызов от гражданского.")
Return

:?:!выз1::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Прибыл на вызов от гражданского.")
Return

:?:!ограб::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Выехал на вызов об ограблении.")
Return

:?:!ограб1::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/r Докладывает: Динеро. Прибыл на вызов об ограблении.")
Return

:?:!обморок::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me снимает набор ПП с плеча и достает аптечку")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me проверяет пульс человека")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me проверяет дыхание человека")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Человек в обмороке.")
Sleep, 3000
sendChat("/me перекладывает человека в горизонтальное положение тела")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me расслабляет стесняющие дыхание элементы одежды")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me пробует привести человека в сознание")
Return

:?:!обморок112::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон и звонит 112, сообщая место, пол и примерный возраст человека")
Sleep, 3000
sendChat("/me проверяет дыхание, пульс, переворачивает человека набок")
Sleep, 3000
sendChat("/me дабы в случае рвоты тот не забылся")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me пробует привести человека в сознание")
Return
:?:!артерия::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me берет телефон и вызывает СМП, затем достает аптечку, открывает и кладет на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me пережимает артерию кулаком в месте ранения, параллельно доставая бинты со жгутом")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me перевязывает место наложения жгута бинтом и накладывает жгут на это место")
Sleep, 3000
sendChat("/me выше ранения, делая первые два тура тугими")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Кровотечение прекращено.")
Return
:?:!вена::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка открыта на полу.")
Sleep, 3000
sendChat("/me протягивает руку в аптечку, после чего берет оттуда марлю")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me накладывает марлю на рану")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me достает из аптечки бинт и вату, после чего кладет вату на марлю и туго бинтует")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Давящая повязка наложена. Кровотечение прекращено.")
Return
:?:!капилляр::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка открыта на полу.")
Sleep, 3000
sendChat("/me достает из аптечки антисептическую повязку")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Антисептическая повязка в руках.")
Sleep, 3000
sendChat("/me обматывает антисептическую повязку на руку")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Кровотечение прекращено.")
Return
:?:!открытый::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me кладет человека на пол")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Человек в горизонтальном положении.")
Sleep, 3000
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me достает медицинскую шину, накладывая ее на место перелома")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me берет бинты и фиксирует ими шину")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Шина зафиксирована.")
Return
:?:!закрытый::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me кладет человека на пол в горизонтальное положение")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Человек в горизонтальном положении.")
Sleep, 3000
sendChat("/me достает телефон, вызывает скорую помощь")
Sleep, 3000
sendChat("/me снимает с разгрузки аптечку, открыв ее, ставит на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
Sleep, 3000
sendChat("/me достает из аптечки медицинскую шину, накладывая ее на место перелома")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/me берет бинты и фиксирует ими шину")
Sleep, 3000
sendChat("/do Процесс...")
Sleep, 3000
sendChat("/do Шина зафиксирована.")
Return
:?:!обморожение::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me берет человека под руку и ведет в теплое место")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/me начинает осторожно растирать пораженные места")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/me достает из разгрузки аптечку и согревающую повязку")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/me накладывает повязку на пораженные участки тела")
Sleep, 3000
sendChat("/do Процесс...")
Return
:?:!пуля::
SendMessage, 0x50,, 0x4190419,, A
sendChat("/me достает телефон, вызывает скорую медицинскую помощь")
Sleep, 3000
sendChat("/me запрокидывает голову человека назад, чуть ее поворачивая")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/me снимает с разгрузки аптечку, открывает ее и ставит на пол")
Sleep, 3000
sendChat("/do Аптечка на полу.")
sendChat("/me достает шприц с обезболивающим из аптечки")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/me вкалывает обезболивающее человеку")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/me достает зеленку из аптечки и обрабатывает ею края раны")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/me достает давящую повязку из аптечки и накладывает ее на пулевое отверстие")
Sleep, 3000
sendChat("/do Процесс...")
sendChat("/do Первая помощь оказана.")
Return

!X::
if (isInChat())
Return
State3 := !State3
If State3
{
Gui, 1:Destroy
Gui, 1:+LastFound +AlwaysOnTop -Caption +ToolWindow +E0x20 +Owner
Gui, 1:Color, 0B0C10
Gui, 1:Margin, 0, 0
Gui, 1:Font, s13 c00E5FF Bold, Segoe UI
Gui, 1:Add, Text, x20 y15 w720 h28 Center vRGB_Title, FENIX DPS HELPER
Gui, 1:Font, s8, Segoe UI
Gui, 1:Add, Text, x20 y45 w720 h2 0x10 vRGB_Line1
Gui, 1:Font, s9 c8A99AD Norm, Segoe UI
Gui, 1:Add, Text, x25 y55 w80 h22, Владелец:
Gui, 1:Font, s9 c00FFC6 Bold, Segoe UI
Gui, 1:Add, Text, x105 y55 w180 h22, Fenix_Dinero (ава Барт)
Gui, 1:Font, s9 c8A99AD Norm, Segoe UI
Gui, 1:Add, Text, x290 y55 w45 h22, VK:
Gui, 1:Font, s9 cFF007F Bold, Segoe UI
Gui, 1:Add, Text, x320 y55 w130 h22, webFenix
Gui, 1:Font, s9 c8A99AD Norm, Segoe UI
Gui, 1:Add, Text, x460 y55 w70 h22, Telegram:
Gui, 1:Font, s9 c00E5FF Bold, Segoe UI
Gui, 1:Add, Text, x530 y55 w180 h22, @webFenix
If (UserID != "")
{
Gui, 1:Font, s9 c8A99AD Norm, Segoe UI
Gui, 1:Add, Text, x25 y80 w90 h22, Текущий ID:
Gui, 1:Font, s9 cFF9F43 Bold, Segoe UI
Gui, 1:Add, Text, x115 y80 w150 h22, %UserID%
}
Gui, 1:Font, s8, Segoe UI
Gui, 1:Add, Text, x20 y105 w720 h2 0x10 vRGB_Line2
Gui, 1:Font, s10 c00E5FF Bold, Segoe UI
Gui, 1:Add, Text, x25 y115 w340 h25, ОСНОВНЫЕ БИНДЫ (Alt + 1..0)
Gui, 1:Font, s8 cE7DFDD Norm, Segoe UI
Gui, 1:Add, Text, x25 y145 w340 h20, Alt + 1 - Ввести ID игрока в биндер
Gui, 1:Add, Text, x25 y165 w340 h20, Alt + 2 - Преследование (/chase)
Gui, 1:Add, Text, x25 y185 w340 h20, Alt + 3 - Посадить в авто (/incar)
Gui, 1:Add, Text, x25 y205 w340 h20, Alt + 4 - Высадить из авто (/deject)
Gui, 1:Add, Text, x25 y225 w340 h20, Alt + 5 - Наручники + Залом (/cuff /frac)
Gui, 1:Add, Text, x25 y245 w340 h20, Alt + 6 - Мегафон (Снизить скорость)
Gui, 1:Add, Text, x25 y265 w340 h20, Alt + 7 - Мегафон (Остановка у обочины)
Gui, 1:Add, Text, x25 y285 w340 h20, Alt + 8 - Мегафон (Спецтранспорт)
Gui, 1:Font, s8 cFF5577 Bold, Segoe UI
Gui, 1:Add, Text, x25 y305 w340 h20, Alt + 9 - Отыгровка СВУ (Дистанционное)
Gui, 1:Add, Text, x25 y325 w340 h20, Alt + 0 - Отыгровка СВУ (Механическое)
Gui, 1:Font, s10 cFF007F Bold, Segoe UI
Gui, 1:Add, Text, x385 y115 w340 h25, КЛАВИШИ (Alt + F1..F5)
Gui, 1:Font, s8 cE7DFDD Norm, Segoe UI
Gui, 1:Add, Text, x385 y145 w340 h20, Alt + F1 - Посадить задержанного в авто
Gui, 1:Add, Text, x385 y165 w340 h20, Alt + F2 - Высадить задержанного из авто
Gui, 1:Add, Text, x385 y185 w340 h20, Alt + F3 - Полный личный досмотр
Gui, 1:Add, Text, x385 y205 w340 h20, Alt + F4 - Изъятие предметов в зип-пакет
Gui, 1:Add, Text, x385 y225 w340 h20, Alt + F5 - Сбив маски (/call 97710514)
Gui, 1:Font, s8, Segoe UI
Gui, 1:Add, Text, x20 y390 w720 h2 0x10 vRGB_Line3
Gui, 1:Font, s10 c00FFC6 Bold, Segoe UI
Gui, 1:Add, Text, x25 y400 w340 h22, БЫСТРЫЕ КОМАНДЫ (ЧАТ)
Gui, 1:Font, s9 cA239CA Norm, Segoe UI
Gui, 1:Add, Text, x25 y420 w340 h18, !миранда, !ук, !коап, !сос, !сос1, !выз, !выз1, !ограб, !ограб1, !визитка
Gui, 1:Font, s10 cFF9F43 Bold, Segoe UI
Gui, 1:Add, Text, x385 y400 w340 h22, МЕДИЦИНА (ЧАТ)
Gui, 1:Font, s9 cA239CA Norm, Segoe UI
Gui, 1:Add, Text, x385 y420 w340 h18, !обморок, !обморок112, !артерия, !вена, !капилляр, !пуля, !открытый
Gui, 1:Font, s8, Segoe UI
Gui, 1:Add, Text, x20 y445 w720 h2 0x10 vRGB_Line4
Gui, 1:Font, s8 c8A99AD Norm, Segoe UI
Gui, 1:Add, Text, x20 y452 w720 h20 Center, Нажмите Alt + X для закрытия окна
Gui, 1:Show, x10 y10 w760 h480 NoActivate, Fenix DPS Helper
WinSet, Transparent, 185, Fenix DPS Helper
SetTimer, RGB_Logic, On
If WinExist("AMAZING ONLINE")
WinActivate, AMAZING ONLINE
}
Else
{
SetTimer, RGB_Logic, Off
Gui, 1:Destroy
}
Return
RGB_Logic:
if (!State3) {
SetTimer, RGB_Logic, Off
Return
}
ColorString := "FF0000|FF7F00|FFFF00|00FF00|0000FF|4B0082|9400D3|00E5FF|FF007F|00FFC6"
ColorArray := StrSplit(ColorString, "|")
if (!ColorIndex || ColorIndex > 10)
ColorIndex := 1
CurrentColor := ColorArray[ColorIndex]
GuiControl, 1:+c%CurrentColor%, RGB_Title
Gui, 1:Font, c%CurrentColor% Bold
GuiControl, 1:Font, RGB_Title
ColorIndex++
Return